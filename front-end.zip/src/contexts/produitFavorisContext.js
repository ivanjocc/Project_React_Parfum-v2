import { createContext } from "react";

const ProduitFavorisContext = createContext({ data: [], setData: null });

export default ProduitFavorisContext;
