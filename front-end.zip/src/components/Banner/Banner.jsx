import React from "react";
import styles from "./Banner.module.scss";

const Banner = () => {
  return <div className={styles.banner}></div>;
};

export default Banner;
